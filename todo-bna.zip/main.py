from rich.console import Console
from rich.table import Table
from datetime import datetime, timedelta

console = Console()
todo_list = []


def add_todo():
    console.print("\n[bold cyan]Add a New Task[/bold cyan]")
    description = input("Enter task description: ")
    due_date_str = input("Enter due date (YYYY-MM-DD HH:MM): ")

    try:
        due_date = datetime.strptime(due_date_str, "%Y-%m-%d %H:%M")
        todo_list.append({"task": description, "due": due_date})
        console.print("[green]Task added successfully![/green]")
    except ValueError:
        console.print("[red]Invalid date format![/red]")


def view_todos():
    if not todo_list:
        console.print("[yellow]No tasks found.[/yellow]")
        return

    console.print("\n[bold]View Options:[/bold]")
    console.print("1. All Pending Tasks")
    console.print("2. Past Tasks")
    console.print("3. Today")
    console.print("4. This Week")
    console.print("5. This Month")

    choice = input("Select option: ")

    now = datetime.now()
    table = Table(title="To-Do List")
    table.add_column("Task", style="magenta")
    table.add_column("Due Date", style="green")

    for item in todo_list:
        due = item["due"]

        if choice == "1" and due < now:
            continue
        elif choice == "2" and due >= now:
            continue
        elif choice == "3" and due.date() != now.date():
            continue
        elif choice == "4" and not (now <= due <= now + timedelta(days=7)):
            continue
        elif choice == "5" and not (due.month == now.month and due.year == now.year):
            continue

        table.add_row(item["task"], due.strftime("%Y-%m-%d %H:%M"))

    console.print(table)


def main():
    while True:
        console.print("\n[bold blue]To-Do App[/bold blue]")
        console.print("1. Add Task")
        console.print("2. View Tasks")
        console.print("3. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            add_todo()
        elif choice == "2":
            view_todos()
        elif choice == "3":
            break
        else:
            console.print("[red]Invalid choice[/red]")


if __name__ == "__main__":
    main()